# Load necessary libraries
if (!require("utils")) install.packages("utils", dependencies = TRUE)
if (!require("readr")) install.packages("readr", dependencies = TRUE)

# Unzip the file
unzip("Employee Profile.zip", exdir = "employee_data")

# Read the CSV file
file_path <- list.files("employee_data", pattern = "\\.csv$", full.names = TRUE)
employee_details <- read_csv(file_path)

# Display the data
print(employee_details)
