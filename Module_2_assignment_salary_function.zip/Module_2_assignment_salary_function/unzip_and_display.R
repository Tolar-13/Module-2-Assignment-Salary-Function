# Load necessary libraries
library(readr)

# Define the name of the zip file and unzip 
zipfile <- "Employee Profile.zip"
employee_data <- read_csv(unz(zipfile, unzip(zipfile, list = TRUE)$Name[1]))

# Display the employee data
print(employee_data)
